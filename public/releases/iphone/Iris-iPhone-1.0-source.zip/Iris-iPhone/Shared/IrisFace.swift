import SwiftUI

enum IrisStyle {
    static let accent = Color(red: 0.91, green: 0.78, blue: 0.43)
    static let background = Color(red: 0.07, green: 0.075, blue: 0.07)
    static let surface = Color(white: 0.13)
}

struct IrisFace: View {
    var size: CGFloat = 70
    var active = false
    var animated = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        TimelineView(.animation(minimumInterval: 1 / 30, paused: !animated || reduceMotion)) { tick in
            let time = tick.date.timeIntervalSinceReferenceDate
            let blink = animated && !reduceMotion && time.truncatingRemainder(dividingBy: 5) < 0.14
            HStack(spacing: size * 0.12) {
                eye(blink: blink)
                eye(blink: blink)
            }
            .frame(width: size, height: size * 0.82)
            .background(.black, in: RoundedRectangle(cornerRadius: size * 0.29, style: .continuous))
            .offset(y: animated && !reduceMotion ? sin(time * 1.4) * 2 : 0)
            .animation(.easeInOut(duration: 0.1), value: blink)
        }.frame(width: size, height: size * 0.9)
            .accessibilityLabel(active ? "Iris is working" : "Iris")
    }
    private func eye(blink: Bool) -> some View {
        Capsule().fill(IrisStyle.accent)
            .frame(width: size * 0.11, height: blink ? size * 0.025 : size * 0.22)
    }
}
