import SwiftUI
import AppIntents

@main struct IrisApp: App {
    @StateObject private var session = IrisSession()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            IrisHome(session: session)
                .preferredColorScheme(.dark)
                .tint(IrisStyle.accent)
                .onOpenURL { url in
                    if url.scheme == "iris", url.host == "ask" { session.summon() }
                }
                .onReceive(NotificationCenter.default.publisher(for: .irisSummoned)) { _ in consumeSummon() }
                .task { await session.cleanOldActivities(); consumeSummon(); IrisShortcuts.updateAppShortcutParameters() }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { consumeSummon() }
            if phase == .background { session.leaveForeground() }
        }
    }
    private func consumeSummon() {
        guard UIApplication.shared.applicationState == .active,
              UserDefaults.standard.bool(forKey: "IrisPendingSummon") else { return }
        UserDefaults.standard.removeObject(forKey: "IrisPendingSummon")
        session.summon()
    }
}

extension Notification.Name { static let irisSummoned = Notification.Name("IrisSummoned") }

struct AskIrisIntent: AppIntent {
    static let title: LocalizedStringResource = "Ask Iris"
    static let description = IntentDescription("Open Iris and start a voice question. You may need to unlock your iPhone.")
    static var openAppWhenRun = true
    @MainActor func perform() async throws -> some IntentResult {
        UserDefaults.standard.set(true, forKey: "IrisPendingSummon")
        NotificationCenter.default.post(name: .irisSummoned, object: nil)
        return .result()
    }
}

struct IrisShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: AskIrisIntent(), phrases: ["Ask \(.applicationName)", "Talk to \(.applicationName)"], shortTitle: "Ask Iris", systemImageName: "waveform")
    }
}
