import SwiftUI
import ActivityKit
import AVFoundation
import Speech

@MainActor final class IrisSession: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var messages: [IrisMessage] = []
    @Published var input = ""
    @Published var phase = "Ready"
    @Published var error: String?
    @Published var busy = false
    @Published var listening = false
    @Published var showSettings = false
    private var work: Task<Void, Never>?
    private var activity: Activity<IrisActivity>?
    private var islandDismiss: Task<Void, Never>?
    private let engine = AVAudioEngine()
    private var recognition: SFSpeechRecognitionTask?
    private var audioRequest: SFSpeechAudioBufferRecognitionRequest?
    private var silence: Task<Void, Never>?
    private var listeningLimit: Task<Void, Never>?
    private var tapInstalled = false
    private var speech = AVSpeechSynthesizer()
    private var spokenSession = false
    private var backgroundTask = UIBackgroundTaskIdentifier.invalid
    private var voiceGeneration = UUID()
    private var requestGeneration = UUID()
    private var transcriptURL: URL { URL.documentsDirectory.appending(path: "conversation.json") }

    override init() {
        super.init()
        speech.delegate = self
        if let data = try? Data(contentsOf: transcriptURL), let saved = try? JSONDecoder().decode([IrisMessage].self, from: data) {
            messages = Array(saved.suffix(100))
        }
    }

    func summon() {
        guard !busy, !listening else { return }
        if IrisKey.read().isEmpty { error = "Add a Gemini API key, then summon Iris again."; showSettings = true; return }
        Task { await startListening() }
    }

    func send(spoken: Bool = false) {
        let prompt = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty, !busy else { return }
        guard !IrisKey.read().isEmpty else { error = "Add your Gemini API key in Settings."; showSettings = true; return }
        stopListening()
        speech.stopSpeaking(at: .immediate)
        input = ""; error = nil; busy = true; spokenSession = spoken
        messages.append(IrisMessage(role: "user", text: prompt))
        let history = messages
        let responseID = UUID()
        messages.append(IrisMessage(id: responseID, role: "assistant", text: ""))
        let generation = UUID(); requestGeneration = generation
        phase = "Writing"
        let key = IrisKey.read()
        let model = UserDefaults.standard.string(forKey: "IrisModel") ?? "gemini-3.8-flash"
        let name = UserDefaults.standard.string(forKey: "IrisName") ?? ""
        work = Task { [weak self] in
            guard let self else { return }
            await self.island("Writing", message: "Working on your answer")
            do {
                try Task.checkCancellation()
                let answer = try await IrisNetwork.stream(messages: history, key: key, model: model, name: name) { [weak self] text in
                    guard let self, self.requestGeneration == generation,
                          let index = self.messages.firstIndex(where: { $0.id == responseID }) else { return }
                    self.messages[index].text = text
                }
                try Task.checkCancellation()
                guard self.requestGeneration == generation else { return }
                self.busy = false; self.phase = "Ready"; self.persist()
                await self.island("Ready", message: "Your answer is ready")
                if spoken || UserDefaults.standard.bool(forKey: "IrisSpeakReplies") { self.speak(answer) }
                else { self.endIslandSoon() }
                self.finishBackgroundTask()
            } catch {
                guard self.requestGeneration == generation else { return }
                if let index = self.messages.firstIndex(where: { $0.id == responseID }), self.messages[index].text.isEmpty { self.messages.remove(at: index) }
                self.busy = false; self.phase = "Ready"
                if !(error is CancellationError) { self.error = error.localizedDescription }
                self.persist(); await self.endIsland(); self.finishBackgroundTask()
            }
        }
    }

    func stop() {
        requestGeneration = UUID()
        work?.cancel(); work = nil
        stopListening(); speech.stopSpeaking(at: .immediate)
        busy = false; phase = "Ready"
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        messages.removeAll { $0.role == "assistant" && $0.text.isEmpty }
        persist(); Task { await endIsland() }; finishBackgroundTask()
    }

    func newConversation() { stop(); messages = []; persist() }

    func startListening() async {
        guard !busy, !listening else { return }
        error = nil
        let generation = UUID(); voiceGeneration = generation
        let speechStatus = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { continuation.resume(returning: $0) }
        }
        guard voiceGeneration == generation else { return }
        let microphone = await AVAudioApplication.requestRecordPermission()
        guard voiceGeneration == generation else { return }
        guard speechStatus == .authorized, microphone else {
            error = "Allow Microphone and Speech Recognition for Iris in iPhone Settings. You can still type."; return
        }
        guard UIApplication.shared.applicationState == .active,
              let recognizer = SFSpeechRecognizer(locale: .current), recognizer.isAvailable else {
            error = "Speech recognition is unavailable right now. Try typing your question."; return
        }
        speech.stopSpeaking(at: .immediate)
        do {
            let audio = AVAudioSession.sharedInstance()
            try audio.setCategory(.playAndRecord, mode: .measurement, options: [.defaultToSpeaker, .mixWithOthers])
            try audio.setActive(true)
            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true
            audioRequest = request
            let node = engine.inputNode
            let format = node.outputFormat(forBus: 0)
            guard format.sampleRate > 0, format.channelCount > 0 else { throw IrisError.message("No microphone is available.") }
            node.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in request.append(buffer) }
            tapInstalled = true
            listening = true; phase = "Listening"; input = ""
            recognition = recognizer.recognitionTask(with: request) { [weak self] result, failure in
                Task { @MainActor in
                    guard let self, self.listening, self.voiceGeneration == generation else { return }
                    if let result {
                        self.input = result.bestTranscription.formattedString
                        self.silence?.cancel()
                        if result.isFinal { self.finishVoice(); return }
                        self.silence = Task { [weak self] in
                            try? await Task.sleep(for: .milliseconds(1600))
                            guard !Task.isCancelled, let self, self.voiceGeneration == generation else { return }
                            self.finishVoice()
                        }
                    }
                    if failure != nil { self.stopListening(); self.error = "Speech input stopped. Please retry or type."; await self.endIsland() }
                }
            }
            engine.prepare(); try engine.start()
            await island("Listening", message: "Speak your question")
            listeningLimit = Task { [weak self] in
                try? await Task.sleep(for: .seconds(30))
                guard !Task.isCancelled, let self, self.voiceGeneration == generation else { return }
                self.finishVoice()
            }
        } catch {
            stopListening(); self.error = error.localizedDescription; await endIsland()
        }
    }

    func finishVoice() {
        guard listening else { return }
        stopListening()
        if input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            error = "I didn’t catch that. Try again or type a question."; Task { await endIsland() }
        } else { send(spoken: true) }
    }

    private func stopListening() {
        voiceGeneration = UUID(); listening = false
        silence?.cancel(); listeningLimit?.cancel()
        engine.stop()
        if tapInstalled { engine.inputNode.removeTap(onBus: 0); tapInstalled = false }
        audioRequest?.endAudio(); recognition?.cancel(); recognition = nil; audioRequest = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        if !busy { phase = "Ready" }
    }

    private func speak(_ text: String) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { self.error = "Audio playback is unavailable."; endIslandSoon(); return }
        let clean = text.replacingOccurrences(of: #"[`*_#]"#, with: "", options: .regularExpression)
        let utterance = AVSpeechUtterance(string: clean)
        utterance.voice = AVSpeechSynthesisVoice(language: Locale.current.language.languageCode?.identifier ?? "en")
        phase = "Speaking"; speech.speak(utterance)
        Task { await island("Speaking", message: "Iris is reading your answer") }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor in
            phase = "Ready"
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            endIslandSoon()
        }
    }

    func leaveForeground() {
        if listening { stopListening(); Task { await endIsland() } }
        if busy, backgroundTask == .invalid {
            backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Finish Iris answer") { [weak self] in
                Task { @MainActor in self?.stop() }
            }
        }
    }

    private func finishBackgroundTask() {
        if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(Array(messages.suffix(100))) {
            try? data.write(to: transcriptURL, options: [.atomic, .completeFileProtection])
        }
    }

    func previewIsland() {
        guard !busy, !listening, phase != "Speaking" else { return }
        Task {
            guard ActivityAuthorizationInfo().areActivitiesEnabled else { error = "Enable Live Activities for Iris in iPhone Settings."; return }
            await island("Ready", message: "Here when you need me")
            endIslandSoon()
        }
    }

    func cleanOldActivities() async {
        for activity in Activity<IrisActivity>.activities { await activity.end(nil, dismissalPolicy: .immediate) }
    }

    private func island(_ phase: String, message: String) async {
        islandDismiss?.cancel()
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let content = ActivityContent(state: IrisActivity.ContentState(phase: phase, message: message), staleDate: .now.addingTimeInterval(90))
        if let activity, activity.activityState == .active { await activity.update(content) }
        else if UIApplication.shared.applicationState == .active {
            do { activity = try Activity.request(attributes: IrisActivity(session: UUID().uuidString), content: content) }
            catch { /* Chat and voice still work when Live Activities are unavailable. */ }
        }
    }

    private func endIslandSoon() {
        islandDismiss?.cancel()
        islandDismiss = Task { [weak self] in
            try? await Task.sleep(for: .seconds(5))
            guard !Task.isCancelled else { return }; await self?.endIsland()
        }
    }
    private func endIsland() async {
        islandDismiss?.cancel()
        let previous = activity
        activity = nil
        if let previous { await previous.end(nil, dismissalPolicy: .immediate) }
    }
}
