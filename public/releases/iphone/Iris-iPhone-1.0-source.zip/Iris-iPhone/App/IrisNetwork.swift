import Foundation
import Security

enum IrisKey {
    static func read() -> String {
        var result: CFTypeRef?
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "IrisGemini", kSecAttrAccount as String: "api-key",
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ key: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "IrisGemini", kSecAttrAccount as String: "api-key"]
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let status: OSStatus
        if trimmed.isEmpty { status = SecItemDelete(query as CFDictionary) }
        else {
            let update = [kSecValueData as String: Data(trimmed.utf8)]
            let existing = SecItemUpdate(query as CFDictionary, update as CFDictionary)
            if existing == errSecItemNotFound {
                status = SecItemAdd(query.merging(update) { _, new in new }.merging([
                    kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
                ]) { _, new in new } as CFDictionary, nil)
            } else { status = existing }
        }
        guard status == errSecSuccess || (trimmed.isEmpty && status == errSecItemNotFound) else {
            throw IrisError.message("Couldn’t save the API key to Keychain (\(status)).")
        }
    }
}

enum IrisError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { text } else { nil } }
}

struct IrisMessage: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String
    var text: String
}

enum IrisNetwork {
    static func stream(messages: [IrisMessage], key: String, model: String, name: String,
                       partial: @escaping @MainActor (String) -> Void) async throws -> String {
        guard !key.isEmpty else { throw IrisError.message("Add your Gemini API key in Settings first.") }
        guard model.range(of: #"^[a-zA-Z0-9.\-_]+$"#, options: .regularExpression) != nil else {
            throw IrisError.message("Choose a valid Gemini model identifier.")
        }
        let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(model):streamGenerateContent?alt=sse")!
        var request = URLRequest(url: url, timeoutInterval: 60)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(key, forHTTPHeaderField: "x-goog-api-key")
        var configuration: [String: Any] = ["maxOutputTokens": 1800]
        if model.hasPrefix("gemini-3") { configuration["thinkingConfig"] = ["thinkingLevel": "low"] }
        var history = Array(messages.suffix(20))
        while history.first?.role == "assistant" { history.removeFirst() }
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "systemInstruction": ["parts": [["text": "You are Iris, a thoughtful personal AI assistant by AriZe on iPhone. The user's saved name is \(name). Be natural and concise. Help with writing, studying, planning and coding. Use readable Markdown. Never pretend to read other apps, control the phone, browse live data, or access the Mac: these are not connected. Ask only for essential missing details. No backend commands. Do not claim actions you cannot perform."]]],
            "contents": history.map { ["role": $0.role == "assistant" ? "model" : "user", "parts": [["text": String($0.text.prefix(12_000))]]] },
            "generationConfig": configuration
        ])
        let (bytes, response) = try await URLSession.shared.bytes(for: request)
        guard let response = response as? HTTPURLResponse else { throw IrisError.message("No response from Gemini.") }
        guard (200..<300).contains(response.statusCode) else {
            let reason = response.statusCode == 429 ? "Gemini quota or rate limit reached. Try later or check your Google API plan." : "Gemini returned HTTP \(response.statusCode). Check your API key and model."
            throw IrisError.message(reason)
        }
        var text = ""
        for try await line in bytes.lines {
            try Task.checkCancellation()
            do { text += try IrisStream.text(from: line) }
            catch { throw IrisError.message("Gemini couldn’t finish this answer. Please retry.") }
            await partial(text)
        }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw IrisError.message("Gemini didn’t return text. Try another question or model.")
        }
        return text
    }
}
