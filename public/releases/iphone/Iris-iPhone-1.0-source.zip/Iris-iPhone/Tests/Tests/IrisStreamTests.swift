import XCTest
@testable import IrisStream
final class IrisStreamTests: XCTestCase {
    func testReasoningAndOtherCandidatesAreNotDisplayed() throws {
        let fixture = #"data: {"candidates":[{"content":{"parts":[{"text":"private reasoning","thought":true},{"text":"Hi "},{"text":"there!"}]}},{"content":{"parts":[{"text":"another answer"}]}}]}"#
        XCTAssertEqual(try IrisStream.text(from: fixture), "Hi there!")
    }
    func testDeltasPreserveMarkdownAndUnicode() throws {
        let lines = [#"data: {"candidates":[{"content":{"parts":[{"text":"**Hello**\n"}]}}]}"#, #"data: {"candidates":[{"content":{"parts":[{"text":"مرحبا"}]}}]}"#]
        XCTAssertEqual(try lines.map(IrisStream.text(from:)).joined(), "**Hello**\nمرحبا")
    }
    func testMetadataAndMalformedLinesNeverLeakIntoChat() throws {
        for line in ["event: message", ": keepalive", "data: [DONE]", "data: {}", "data: broken"] {
            XCTAssertEqual(try IrisStream.text(from: line), "")
        }
    }
    func testProviderErrorCannotBeMistakenForSuccessfulAnswer() {
        XCTAssertThrowsError(try IrisStream.text(from: #"data: {"error":{"code":429,"message":"Quota"}}"#))
    }
}
