# Iris for iPhone — 1.0 preview

A separate iPhone companion by AriZe. Requires iOS 18 or later. Uses Gemini for streamed text; a user-supplied API key is stored in iPhone Keychain. Voice input uses Apple Speech with visible foreground capture and pause-to-send. Spoken answers use the iPhone speech synthesizer; Gemini TTS and Mac account/connection sync are not included in this preview.

## Dynamic Island and Action Button

No Live Activity is created on ordinary launch. Ask Iris from Shortcuts (or `iris://ask`) to open the app and start listening. Configure that shortcut under Settings → Action Button → Shortcut. Unlock may be required. A Live Activity shows status while listening, writing, or speaking, then ends. The Island is controlled by iOS and cannot host a custom keyboard or always-running assistant. Without a Dynamic Island, the session appears on the Lock Screen. Other apps' content and screen control are not accessible.

The widget extension contains the Lock Screen and compact/minimal/expanded Island layouts. No push notifications, app groups, external servers, or paid Apple entitlements are required by this implementation. Keep the IrisIsland extension when re-signing the IPA.

## Install without a paid Apple Developer membership

The published IPA is an **unsigned device build for re-signing**, not a Safari-installable enterprise app. Use AltStore Classic with AltServer on a Mac or PC, and your own Apple account. Follow https://faq.altstore.io/altstore-classic/how-to-install-altstore-macos (or its Windows counterpart). Download the IPA, then choose it in AltStore → My Apps → +. Keep extensions when asked. Trust your developer profile and enable Developer Mode only as instructed by Apple's prompts and the official AltStore guide. A free account normally requires refreshing apps every 7 days and is limited to 3 active sideloaded apps, including AltStore. Extensions consume additional App IDs. Neither AriZe nor this website asks for your Apple password.

Alternatively, open Iris.xcodeproj in Xcode, add your own Apple account in Xcode Settings, choose your Personal Team on both targets, connect your iPhone and Run. Bundle identifiers may need a unique suffix on both targets (the extension ID must begin with the main app ID). Do not enable a capability that your Personal Team does not support. If the signer cannot provision the extension, the full Dynamic Island build cannot be installed with that signer; use Xcode and report the exact provisioning error rather than removing the extension silently.

## Build

No package dependencies. Xcode with the iOS 18+ SDK is required.

```
xcodebuild -project Iris.xcodeproj -scheme Iris -configuration Release -destination 'generic/platform=iOS' -derivedDataPath Build CODE_SIGNING_ALLOWED=NO build
```

Put `Build/Build/Products/Release-iphoneos/Iris.app` inside a directory named `Payload`, then ZIP that directory as `Iris-iPhone-1.0.ipa`. The app must be signed for your own device by your sideloader before installation. No signing certificate or personal provisioning profile is distributed.

## Verification

Device and simulator builds are checked separately. A simulator build cannot be installed on a real phone. A physical-phone installation and Apple-account re-signing are not validated until completed on that device. Never claim an unsigned build is already device-installable.

Public guide: https://projectiris.lovelyabbey.chatgpt.site/iphone
